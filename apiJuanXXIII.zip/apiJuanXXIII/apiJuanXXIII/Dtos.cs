﻿using System;

namespace apiJuanXXIII
{
    public record CargoDTO(int codigo, string nombre);
    public record ComunaDTO(int codigo, string nombre);
    public record ColegioDTO(string codigo, string nombre, string codigotipo, string comuna, string direccion, string telefono, string director, bool sector, int movilizacion, string texto, int colacion, string jornada, int pme);

}
